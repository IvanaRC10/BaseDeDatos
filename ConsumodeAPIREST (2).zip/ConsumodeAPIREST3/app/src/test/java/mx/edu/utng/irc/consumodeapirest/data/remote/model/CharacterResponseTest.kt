package mx.edu.utng.irc.consumodeapirest.data.remote.model

import org.junit.jupiter.api.Assertions.*

class CharacterResponseTest {

}