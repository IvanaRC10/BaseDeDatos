package mx.edu.utng.irc.consumodeapirest.data.remote.model

import mx.edu.utng.irc.consumodeapirest.data.remote.RickAndMortyApiService
import retrofit2.Response

class RickAndMortyApiServiceImpl : RickAndMortyApiService {
    /**
     * Obtiene una página de personajes de la API.
     * Endpoint: /character?page={page}
     *
     * La función es 'suspend' para usarse dentro de Coroutines,
     * lo cual es estándar para operaciones de red asíncronas en Kotlin.
     * * @param page Número de página a solicitar (valor predeterminado: 1).
     * @return Response<CharacterResponse> que contiene la respuesta HTTP y el cuerpo deserializado.
     */
    override suspend fun getCharacters(page: Int): Response<CharacterResponse> {
        TODO("Not yet implemented")
    }
}