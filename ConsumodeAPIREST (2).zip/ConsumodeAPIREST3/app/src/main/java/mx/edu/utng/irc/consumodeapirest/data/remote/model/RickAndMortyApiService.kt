package mx.edu.utng.irc.consumodeapirest.data.remote

// ¡IMPORTANTE! Se corrigió la importación de @Query
import mx.edu.utng.irc.consumodeapirest.data.remote.model.CharacterResponse
import retrofit2.http.Query
import retrofit2.Response
import retrofit2.http.GET

/**
 * Interfaz de servicio de Retrofit.
 * Define los endpoints de la API de Rick and Morty.
 */
interface RickAndMortyApiService {

    /**
     * Obtiene una página de personajes de la API.
     * Endpoint: /character?page={page}
     *
     * La función es 'suspend' para usarse dentro de Coroutines,
     * lo cual es estándar para operaciones de red asíncronas en Kotlin.
     * @param page Número de página a solicitar (valor predeterminado: 1).
     * @return Response<CharacterResponse> que contiene la respuesta HTTP y el cuerpo deserializado.
     */
    @GET("character")
    suspend fun getCharacters(
        @Query("page") page: Int = 1 // Parámetro de query para la paginación
    ): Response<CharacterResponse>

    // Ejemplo:
    // @GET("character/{id}")
    // suspend fun getSingleCharacter(@Path("id") characterId: Int): Response<Character>
}