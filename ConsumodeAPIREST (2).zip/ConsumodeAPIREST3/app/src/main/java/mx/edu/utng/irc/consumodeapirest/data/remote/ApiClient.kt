package mx.edu.utng.irc.consumodeapirest.data.remote



object ApiClient {
    // Instancia el servicio de la API (definido en Fase 3)
    val rickAndMortyService: RickAndMortyApiService by lazy {
        RetrofitClient.retrofit.create(RickAndMortyApiService::class.java)
    }
}