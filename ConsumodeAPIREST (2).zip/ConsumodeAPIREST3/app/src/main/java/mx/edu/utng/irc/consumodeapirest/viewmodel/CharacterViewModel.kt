package mx.edu.utng.irc.consumodeapirest.viewmodel


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import mx.edu.utng.irc.consumodeapirest.data.remote.ApiClient
import mx.edu.utng.irc.consumodeapirest.data.remote.model.CharacterResponse
import mx.edu.utng.irc.consumodeapirest.data.repository.CharacterRepository
import mx.edu.utng.irc.consumodeapirest.data.repository.NetworkResult

class CharacterViewModel : ViewModel() {

    // Inicializa el Repository y el ApiClient
    private val repository = CharacterRepository(ApiClient)

    // Estado privado (MutableStateFlow) que se actualiza desde el ViewModel
    private val _charactersState = MutableStateFlow<NetworkResult<CharacterResponse>>(NetworkResult.Loading())

    // Estado público (StateFlow) para que la UI lo observe de forma segura (inmutable)
    val charactersState: StateFlow<NetworkResult<CharacterResponse>> = _charactersState.asStateFlow()

    init {
        // Carga los personajes tan pronto como el ViewModel se crea
        loadCharacters()
    }

    /**
     * Inicia la coroutine para obtener los personajes y recolectar los estados del Flow del Repository.
     */
    fun loadCharacters() {
        // Inicia una coroutine que se cancela automáticamente cuando el ViewModel es destruido
        viewModelScope.launch {
            repository.getCharactersFlow().collectLatest { result ->
                // Actualiza el estado privado con el resultado (Loading, Success o Error)
                _charactersState.value = result
            }
        }
    }
}