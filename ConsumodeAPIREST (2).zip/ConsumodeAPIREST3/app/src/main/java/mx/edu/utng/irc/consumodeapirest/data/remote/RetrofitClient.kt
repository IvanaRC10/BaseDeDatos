package mx.edu.utng.irc.consumodeapirest.data.remote

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Objeto Singleton que configura y proporciona la instancia de Retrofit.
 * Se utiliza un objeto (en lugar de una clase) para asegurar que solo haya una instancia
 * del cliente HTTP en toda la aplicación.
 */
object RetrofitClient {

    // URL base de la API de Rick and Morty para realizar peticiones.
    private const val BASE_URL = "https://rickandmortyapi.com/api/"

    /**
     * Interceptor para logging: Muestra detalles de la solicitud y la respuesta
     * (headers, cuerpo, etc.) en Logcat, muy útil para la depuración.
     */
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    /**
     * Cliente OkHttpClient configurado con el interceptor de logging y timeouts.
     */
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        // Establecer tiempos de espera (timeouts) para la conexión
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Instancia de Retrofit configurada. Esta es la propiedad que usarán otros componentes.
     */
    val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient) // Asignar el cliente OkHttp configurado
        .addConverterFactory(GsonConverterFactory.create()) // Conversor de JSON (Gson)
        .build()
}
