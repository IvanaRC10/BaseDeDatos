package mx.edu.utng.irc.consumodeapirest.data.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import mx.edu.utng.irc.consumodeapirest.data.remote.ApiClient
import mx.edu.utng.irc.consumodeapirest.data.remote.model.CharacterResponse
import java.io.IOException

class CharacterRepository(private val apiService: ApiClient) {

    /**
     * Función que obtiene personajes y emite el estado del resultado (Loading, Success, Error)
     * a través de un Flow.
     */
    fun getCharactersFlow(): Flow<NetworkResult<CharacterResponse>> = flow {
        // 1. Emite el estado de Carga (Loading)
        emit(NetworkResult.Loading())

        try {
            // 2. Realiza la llamada a la API
            val response = apiService.rickAndMortyService.getCharacters()

            // 3. Evalúa la respuesta HTTP
            if (response.isSuccessful && response.body() != null) {
                // Éxito: Emite el resultado exitoso con los datos
                emit(NetworkResult.Success(response.body()!!))
            } else {
                // Error HTTP (4xx, 5xx): Emite el mensaje de error
                val errorMessage = response.errorBody()?.string() ?: "Error desconocido en la API"
                emit(NetworkResult.Error("Error ${response.code()}: $errorMessage"))
            }
        } catch (e: IOException) {
            // Error de Conexión: Emite un error de red
            emit(NetworkResult.Error("Error de red. Verifica tu conexión a Internet."))
        } catch (e: Exception) {
            // Otros Errores: Emite un error genérico
            emit(NetworkResult.Error("Ha ocurrido un error inesperado: ${e.localizedMessage}"))
        }
    }.flowOn(Dispatchers.IO) // Asegura que la operación de red corra en el hilo de I/O
}