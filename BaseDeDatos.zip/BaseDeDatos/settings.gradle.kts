pluginManagement {
    repositories {
        // Plugins de Android y Google (AGP, Compose Compiler, etc.)
        google()

        // Plugins genéricos de Gradle
        gradlePluginPortal()

        // Otros plugins comunes
        mavenCentral()
    }
}

dependencyResolutionManagement {
    // Permite que todos los módulos usen solo los repositorios aquí definidos
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)

    repositories {
        // Repositorios para las dependencias del proyecto (Room, Compose, Core KTX, etc.)
        google()
        mavenCentral()
    }
}

// Configuración de proyectos
rootProject.name = "BaseDeDatos"
include(":app")
