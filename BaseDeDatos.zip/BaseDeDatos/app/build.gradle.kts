plugins {
    id("com.android.application")
    // ¡CLAVE! Especifica la versión de Kotlin para asegurar la compatibilidad
    id("org.jetbrains.kotlin.android") version "1.9.22" // Compatible con KSP 1.9.22-1.0.17
    id("com.google.devtools.ksp") version "1.9.22-1.0.17"
    id("org.jetbrains.kotlin.plugin.compose") // Ahora se toma la versión 1.9.22
}

android {
    namespace = "mx.edu.utng.irc.basededatos"
    compileSdk = 34

    defaultConfig {
        applicationId = "mx.edu.utng.irc.basededatos"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        // ¡CLAVE! Esta versión de la extensión DEBE ser compatible con Kotlin 1.9.22
        kotlinCompilerExtensionVersion = "1.5.12"
    }
}

dependencies {
    // --- VERSIONES ACTUALIZADAS Y ALINEADAS ---
    val room_version = "2.6.1"
    val compose_bom_version = "2024.10.00"
    val lifecycle_version = "2.8.3"

    // Compose BOM
    val composeBom = platform("androidx.compose:compose-bom:$compose_bom_version")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    // Core AndroidX
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:$lifecycle_version")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:$lifecycle_version")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Jetpack Compose
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Room
    implementation("androidx.room:room-runtime:$room_version")
    implementation("androidx.room:room-ktx:$room_version")
    ksp("androidx.room:room-compiler:$room_version") // KSP procesa este compilador

    // Tests
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")

    // Compose Tests
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}