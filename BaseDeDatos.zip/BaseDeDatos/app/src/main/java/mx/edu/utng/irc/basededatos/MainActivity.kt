package mx.edu.utng.irc.basededatos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import mx.edu.utng.irc.basededatos.ui.theme.BaseDeDatosTheme

class MainActivity : ComponentActivity() {

    // Inicializamos la base de datos, el repositorio y el ViewModel
    private val database by lazy { AppDatabase.getDatabase(this) }
    private val repository by lazy { EstudianteRepository(database.estudianteDao()) }
    private val viewModel by viewModels<EstudianteViewModel> {
        EstudianteViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BaseDeDatosTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PantallaEstudiantes(viewModel = viewModel)
                }
            }
        }
    }
}
