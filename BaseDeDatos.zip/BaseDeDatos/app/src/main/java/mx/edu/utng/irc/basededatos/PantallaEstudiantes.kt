package mx.edu.utng.irc.basededatos

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun PantallaEstudiantes(viewModel: EstudianteViewModel) {
    val estudiantes by viewModel.todosLosEstudiantes.collectAsState()

    var nombre by remember { mutableStateOf("") }
    var matricula by remember { mutableStateOf("") }
    var promedio by remember { mutableStateOf("") }
    var mostrarError by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Gestión de Estudiantes",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Registrar Nuevo Estudiante",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                OutlinedTextField(
                    value = nombre,
                    onValueChange = {
                        nombre = it
                        mostrarError = false
                    },
                    label = { Text("Nombre completo") },
                    placeholder = { Text("Ej: Ana María López") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = matricula,
                    onValueChange = {
                        matricula = it
                        mostrarError = false
                    },
                    label = { Text("Matrícula") },
                    placeholder = { Text("Ej: 2024001") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = promedio,
                    onValueChange = {
                        promedio = it
                        mostrarError = false
                    },
                    label = { Text("Promedio") },
                    placeholder = { Text("Ej: 9.5") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (mostrarError) {
                    Text(
                        text = "Por favor completa todos los campos correctamente",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (nombre.isNotBlank() &&
                            matricula.isNotBlank() &&
                            promedio.isNotBlank()
                        ) {
                            val promedioValor = promedio.toDoubleOrNull()
                            if (promedioValor != null && promedioValor in 0.0..10.0) {
                                viewModel.agregarEstudiante(
                                    nombre = nombre.trim(),
                                    matricula = matricula.trim(),
                                    promedio = promedioValor
                                )
                                nombre = ""
                                matricula = ""
                                promedio = ""
                                mostrarError = false
                            } else {
                                mostrarError = true
                            }
                        } else {
                            mostrarError = true
                        }
                    },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Agregar Estudiante")
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Lista de Estudiantes (${estudiantes.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            if (estudiantes.isNotEmpty()) {
                val promedioGeneral = estudiantes.map { it.promedio }.average()
                Text(
                    text = "Promedio: ${String.format("%.2f", promedioGeneral)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        if (estudiantes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.Person,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No hay estudiantes registrados",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(estudiantes, key = { it.id }) { estudiante ->
                    EstudianteItem(estudiante = estudiante) {
                        viewModel.eliminarEstudiante(estudiante)
                    }
                }
            }
        }
    }
}

@Composable
fun EstudianteItem(estudiante: Estudiante, onEliminar: () -> Unit) {
    var mostrarDialogo by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(estudiante.nombre, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Badge, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Matrícula: ${estudiante.matricula}", style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.Star,
                        null,
                        Modifier.size(16.dp),
                        tint = when {
                            estudiante.promedio >= 9 -> Color(0xFF4CAF50)
                            estudiante.promedio >= 7 -> Color(0xFFFFC107)
                            else -> Color(0xFFF44336)
                        }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Promedio: ${String.format("%.2f", estudiante.promedio)}")
                }

                val fecha = remember(estudiante.fechaInscripcion) {
                    SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(estudiante.fechaInscripcion))
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text("Inscrito: $fecha", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            }

            IconButton(onClick = { mostrarDialogo = true }) {
                Icon(Icons.Filled.Delete, "Eliminar estudiante", tint = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (mostrarDialogo) {
        AlertDialog(
            onDismissRequest = { mostrarDialogo = false },
            title = { Text("Confirmar eliminación") },
            text = { Text("¿Eliminar a ${estudiante.nombre}? Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = {
                    onEliminar()
                    mostrarDialogo = false
                }) {
                    Text("Eliminar", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarDialogo = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}
