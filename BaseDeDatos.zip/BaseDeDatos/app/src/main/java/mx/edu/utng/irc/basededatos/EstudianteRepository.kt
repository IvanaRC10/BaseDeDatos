package mx.edu.utng.irc.basededatos

import kotlinx.coroutines.flow.Flow

class EstudianteRepository(private val estudianteDao: EstudianteDao) {
    val todosLosEstudiantes: Flow<List<Estudiante>> = estudianteDao.obtenerTodosLosEstudiantes()

    suspend fun insertar(est: Estudiante) = estudianteDao.insertarEstudiante(est)
    suspend fun actualizar(est: Estudiante) = estudianteDao.actualizarEstudiante(est)
    suspend fun eliminar(est: Estudiante) = estudianteDao.eliminarEstudiante(est)
    suspend fun eliminarTodos() = estudianteDao.eliminarTodos()
    suspend fun buscarPorMatricula(m: String) = estudianteDao.buscarPorMatricula(m)
}
