package mx.edu.utng.irc.basededatos

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.google.android.filament.Entity

@Entity(
    tableName = "estudiantes",
    indices = [Index(value = ["matricula"], unique = true)]
)
data class Estudiante(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "nombre_completo") val nombre: String,
    val matricula: String,
    val promedio: Double,
    val fechaInscripcion: Long = System.currentTimeMillis()
)
