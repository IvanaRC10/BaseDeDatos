package mx.edu.utng.irc.basededatos

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class EstudianteViewModel(private val repository: EstudianteRepository) : ViewModel() {
    val todosLosEstudiantes: StateFlow<List<Estudiante>> =
        repository.todosLosEstudiantes
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun agregarEstudiante(nombre: String, matricula: String, promedio: Double) {
        viewModelScope.launch {
            repository.insertar(Estudiante(nombre = nombre, matricula = matricula, promedio = promedio))
        }
    }

    fun eliminarEstudiante(est: Estudiante) {
        viewModelScope.launch { repository.eliminar(est) }
    }
}

// Factory
class EstudianteViewModelFactory(private val repository: EstudianteRepository)
    : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EstudianteViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EstudianteViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}