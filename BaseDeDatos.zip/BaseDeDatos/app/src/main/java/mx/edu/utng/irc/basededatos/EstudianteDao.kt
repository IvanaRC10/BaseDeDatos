package mx.edu.utng.irc.basededatos




import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import kotlinx.coroutines.flow.Flow

@Dao
interface EstudianteDao {

    @Insert
    suspend fun insertar(estudiante: Estudiante)

    @Update
    suspend fun actualizar(estudiante: Estudiante)

    @Delete
    suspend fun eliminar(estudiante: Estudiante)

    @Query("SELECT * FROM estudiantes ORDER BY nombre_completo ASC")
    suspend fun obtenerTodos(): List<Estudiante>

    @Query("SELECT * FROM estudiantes WHERE matricula = :matricula LIMIT 1")
    suspend fun buscarPorMatricula(matricula: String): Estudiante?
    fun obtenerTodosLosEstudiantes(): Flow<List<Estudiante>>
    fun insertarEstudiante(est: Estudiante): Any
    fun actualizarEstudiante(est: Estudiante): Any
    fun eliminarEstudiante(est: Estudiante): Any
    fun eliminarTodos(): Any
}
