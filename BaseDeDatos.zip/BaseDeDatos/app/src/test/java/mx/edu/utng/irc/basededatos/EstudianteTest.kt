package mx.edu.utng.irc.basededatos

import org.junit.jupiter.api.Assertions.*

class EstudianteTest {

}